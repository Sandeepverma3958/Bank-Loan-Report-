--Bank Loan Report Query 

--KPI's

--Total Loan Application 

Select count(id) as Total_Application from financial_loan;

     --Total Application = 38576

--MTD loan Applictions

Select count(id) as Total_Applications from financial_loan 
where month(issue_date) = 12;
  -- Total_app = 4314

--PMTD Loan Applications
Select count(id) as Total_Application from financial_loan
where month(issue_date) = 11
   
   --PMTD Loan Applications = 4035

--Total Funded Amount 
Select sum(loan_amount) as Total_Funded_Amount from financial_loan;

  --Total_Funded_Amount = 435757075

--MTD Total Funded Amount 

SELECT SUM(loan_amount) AS Total_Funded_Amount FROM financial_loan
WHERE MONTH(issue_date) = 12

    --MTD Total Funded Amount =  53981425

--PMTD Total Funded Amount 

SELECT SUM(loan_amount) AS Total_Funded_Amount FROM financial_loan
WHERE MONTH(issue_date) = 11
   ----PMTD Total Funded Amount = 47754825

--Total Amount Received 

SELECT SUM(total_payment) AS Total_Amount_Collected FROM financial_loan;

  --Total Amount Received = 473070933

--MTD Total Amount Received

SELECT SUM(total_payment) AS Total_Amount_Collected FROM financial_loan
WHERE MONTH(issue_date) = 12

 --MTD Total Amount Received = 58074380

--PMTD Total Amount Received 

SELECT SUM(total_payment) AS Total_Amount_Collected FROM financial_loan
WHERE MONTH(issue_date) = 11

   ----PMTD Total Amount Received = 50132030

--Average Interest Rate

SELECT AVG(int_rate)*100 AS Avg_Int_Rate FROM financial_loan;

  --Average Interest Rate = 12.0488314172048

--MTD Average Interest

SELECT avg(int_rate) * 100 as MTD_Avg from financial_loan 
where month(issue_date) = 12;
  
  --MTD Average Interest = 12.3560408676042


--PMTD Average Interest

Select avg(int_rate) * 100 as PMTD_avg_Int_rate from financial_loan 
where month(issue_date) = 11;

  --PMTD Average Interest = 11.9417175498261

--Avg DTI 

select avg(dti) *100 as avg_dti from financial_loan;
  
  --Avg DTI = 13.3274331211432

--MTD Avg DTI

select avg(dti) * 100 as MTD_avg_DTI from financial_loan 
where month(issue_date) = 12

  ----MTD Avg DTI = 13.6655377880425



--PMTD Avg DTI

select avg(dti) * 100 as PMTD_Avg_DTI from financial_loan
where month(issue_date) = 11;

--GOOD LOAN ISSUED

--Good Loan Percentage

select (count(case when loan_status = 'Fully Paid' or loan_status = 'current' then id 
end) *100.0) / count(id) as Good_loan_percentage 
from financial_loan;

--Good Loan Applications

SELECT COUNT(id) AS Good_Loan_Applications FROM financial_loan
WHERE loan_status = 'Fully Paid' OR loan_status = 'Current'

--Good_loan_Application = 33243

--Good Loan Funded Amount 

Select sum(loan_amount) as Good_loan_funded_amount from financial_loan 
where loan_status = 'Fully_Paid'  or loan_status = 'Current'


--Good loan Amount Received 

select sum(total_payment) as Good_loan_amount_received from financial_loan 
where loan_status = 'Fully Paid ' or loan_status = 'Current';

--BAD LOAN ISSUED

--Bad Loan Percentage

SELECT
(COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0) /
COUNT(id) AS Bad_Loan_Percentage
FROM financial_loan;


--Bad Loan Applications

SELECT COUNT(id) AS Bad_Loan_Applications FROM financial_loan
WHERE loan_status = 'Charged Off'

--Bad Loan funded Amount 

Select sum(loan_amount) as Bad_loan_funded_amount from financial_loan 
where loan_status = 'Carged off';

--Bad Loan Amount Received 

Select sum(total_payment)  as Bad_loan_amount_received from financial_loan 
where loan_status = 'Charged Off';

--LOAN STATUS

SELECT
loan_status,
COUNT(id) AS LoanCount,
SUM(total_payment) AS Total_Amount_Received,
SUM(loan_amount) AS Total_Funded_Amount,
AVG(int_rate * 100) AS Interest_Rate,
AVG(dti * 100) AS DTI
FROM
financial_loan
GROUP BY
loan_status


SELECT
loan_status,
SUM(total_payment) AS MTD_Total_Amount_Received,
SUM(loan_amount) AS MTD_Total_Funded_Amount
FROM financial_loan
WHERE MONTH(issue_date) = 12
GROUP BY loan_status

--B. BANK LOAN REPORT | OVERVIEW

--MONTH

SELECT
MONTH(issue_date) AS Month_Munber,
DATENAME(MONTH, issue_date) AS Month_name,
COUNT(id) AS Total_Loan_Applications,
SUM(loan_amount) AS Total_Funded_Amount,
SUM(total_payment) AS Total_Amount_Received
FROM financial_loan
GROUP BY MONTH(issue_date), DATENAME(MONTH, issue_date)
ORDER BY MONTH(issue_date)


--STATE

SELECT
address_state AS State,
COUNT(id) AS Total_Loan_Applications,
SUM(loan_amount) AS Total_Funded_Amount,
SUM(total_payment) AS Total_Amount_Received
FROM financial_loan
GROUP BY address_state
ORDER BY address_state


--TERM

SELECT
term AS Term,
COUNT(id) AS Total_Loan_Applications,
SUM(loan_amount) AS Total_Funded_Amount,
SUM(total_payment) AS Total_Amount_Received
FROM financial_loan
GROUP BY term
ORDER BY term

--EMPLOYEE LENGTH

SELECT
emp_length AS Employee_Length,
COUNT(id) AS Total_Loan_Applications,
SUM(loan_amount) AS Total_Funded_Amount,
SUM(total_payment) AS Total_Amount_Received
FROM financial_loan
GROUP BY emp_length
ORDER BY emp_length

--PURPOSE

SELECT
purpose AS PURPOSE,
COUNT(id) AS Total_Loan_Applications,
SUM(loan_amount) AS Total_Funded_Amount,
SUM(total_payment) AS Total_Amount_Received
FROM financial_loan
GROUP BY purpose
ORDER BY PURPOSE


--HOME OWNERSHIP


SELECT
home_ownership AS Home_Ownership,
COUNT(id) AS Total_Loan_Applications,
SUM(loan_amount) AS Total_Funded_Amount,
SUM(total_payment) AS Total_Amount_Received
FROM financial_loan
GROUP BY home_ownership
ORDER BY home_ownership


/*Note: We have applied multiple Filters on all the dashboards. You can check the results for
the filters as well by modifying the query and comparing the results.*/

